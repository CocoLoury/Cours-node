
// Création d'un serveur sous NODE

// Chargement du module natif "http"
var http = require('http');
// Chargement de mon module natif "monModule" à la racine de l'app (./)
var monModule = require('./monModule');

// Création du serveur
var server = http.createServer(function(req, res){

  console.log("Un client accède au serveur")

  //res.writeHead(200, {'Content-Type' : 'text/html' , 'charset' : 'utf-8' })
  res.writeHead(200, {"Content-Type" : "text/html; charset=utf-8"});
  /* ou */
  //res.statusCode = 200;
  //res.setHeader('Content-Type', 'text/html');

  //res.end("Bonjour je suis ton serveur Node");

  res.write('<html><body><h1> Année de naissance : '+monModule.naissance+'</h1>'+monModule.age()+'</body></html>');
  res.end();

});

// Ecouter le port XXXX
server.listen(3000);
console.log("Serveur lancé, consultez le port localhost:3000 !")
