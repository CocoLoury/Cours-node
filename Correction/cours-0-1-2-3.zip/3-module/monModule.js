

// Expoter une variable
var naissance = 1983
exports.naissance = naissance

// Exporter une méthode
var age = function(){

    var annee = new Date().getFullYear();
    var monAge = annee - naissance - 1;
    return "<h2 style='color:red'>Mon age est "+monAge+"</h2>"

}

exports.age = age
